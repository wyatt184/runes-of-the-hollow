Open Runes_of_the_Hollow.html. The trailer plays before the main menu. Use Sound On if your browser blocks autoplay audio, or Skip Trailer to go straight to the game.
