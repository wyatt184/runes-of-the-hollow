RUNES OF THE HOLLOW — BALANCE UPDATE

Open Runes_of_the_Hollow.html in your browser to play.
The loading trailer has been removed, so the game opens directly to the menu.

GLOBAL CHANGES
- Z attack stages no longer reset to Z1 just because you stop attacking.
- Added attack-animation feedback for heroes.
- Added anti-status-spam protection: hard crowd control cannot be chained forever, long slows/statuses get recovery windows, and major poison/burn/status applications cannot be endlessly refreshed by repeated hits.
- Kept the broader roster's normal base-stat ranges intact so hero roles still feel different.

HERO BALANCE / REWORK PASS
Aurel Rune Warden
- Q cooldown: 30s.
- Only one ground rune at a time; 10s placement cooldown.
- Ground runes have lower, decaying HP and a 7s maximum lifetime; enemy attacks kill them faster.
- Z1/Z2/Z3 have distinct rune visuals.
- R reworked to Ground Tremor: 25 damage, 1s stun, compact ring around Aurel.

Seraph Ember Seer
- Z4 healing removed; now fires four piercing projectiles.
- Burn from Z only applies while Flame Infusion (T) is active.
- Q visual reworked.
- R area enlarged by about 35%; oil wording removed from the placed-area presentation.

Neris Tide Sage
- Z/trident damage reduced; trident stays deployed rather than resetting from attack inactivity.
- Z3 damage/radius/push/control reduced.
- R damage reduced substantially.

Cael Gale Weaver
- Q deployable is only preferred by enemies when it is closer than Cael.
- Z damage reduced heavily; Z knockback removed.
- Q and R visuals reworked.
- R damage/push reduced.

Mora Briar Druid
- Q/T/E deployables are only preferred by enemies when they are closer than Mora.
- Enchantment circle now spawns on Mora.
- Z4 slow reduced from 95% to 25% and shortened.

Orun Astral Monk
- Starfall damage reduced to 30 per star with much stronger tracking.
- Moldy Baguette damage reduced and now pierces.
- Gravity Well control reduced.
- R status duration increased to 4s while direct R damage was reduced to keep it fair.

Lyra Moon Huntress
- Status effects removed from normal Z attacks.
- Q cooldown: 22s.
- R damage reduced; arrows have strong homing and spread across multiple enemies.
- Deals 50% reduced damage to bosses.

Vesper Chronomagus
- Z2 return volley angle/path fixed.
- Stored charge now powers the next Z1.
- Z4 time-status duration reduced.
- R damage reduced.

Nyx Void Reaver
- T clone damage reduced to roughly 25% of Nyx's matching attacks.
- Shotgun/split, Z, shuriken and beam damage reduced.
- Madness removed from normal Z attacks.
- Beam has no knockback.
- R reworked into a lower-damage chaotic/random effect set.

Solen Prism Smith
Form 1:
- Q laser turret spawns on Solen, lasts up to 7s, deals 5 damage per reliable hit, has decaying HP, and can be destroyed faster by enemies.
- Enemies only prefer the turret when it is closer than Solen.
- T Miniaturizer spawns on Solen and only needs to survive 3s.
- Form 1 R damage banking reduced for balance.
Form 2:
- Z projectiles can bounce off walls once.
- Q Splitting Sickle can split twice and bounce off walls up to three times.
- Magnet Shell changed from full invulnerability to strong damage reduction.
