Runes of the Hollow — Balance Update

Open Runes_of_the_Hollow.html in a modern browser to play.

This build removes the loading trailer and includes the hero balance/rework pass discussed in chat, including persistent Z combo stages and anti-status-spam protections.
